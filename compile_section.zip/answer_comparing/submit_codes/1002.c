#include <stdio.h>
int main()
{
	printf("12312312355");
}